const loadingScreen = document.getElementById("loadingScreen");
const loadingBar = document.getElementById("loadingBar");
const loadingPercent = document.getElementById("loadingPercent");

if (loadingScreen && loadingBar && loadingPercent) {
  document.body.style.overflow = "hidden";
  let progress = 0;
  const finishLoading = () => {
    loadingScreen.classList.add("loaded");
    document.body.style.overflow = "";
    setTimeout(() => loadingScreen.remove(), 700);
  };
  const tick = () => {
    progress += Math.random() * 18 + 6;
    if (progress >= 100) {
      progress = 100;
      loadingBar.style.width = "100%";
      loadingPercent.textContent = "100%";
      setTimeout(finishLoading, 350);
      return;
    }
    loadingBar.style.width = progress + "%";
    loadingPercent.textContent = Math.floor(progress) + "%";
    setTimeout(tick, 180);
  };
  tick();
}

const menuBtn = document.getElementById("menuBtn");
const mobileMenu = document.getElementById("mobileMenu");
const cursorDot = document.getElementById("cursorDot");

menuBtn?.addEventListener("click", () => {
  const open = mobileMenu.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", String(open));
});

mobileMenu?.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    mobileMenu.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("show");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

document.getElementById("year").textContent = new Date().getFullYear();

if (window.matchMedia("(pointer:fine)").matches) {
  window.addEventListener("pointermove", e => {
    cursorDot.style.left = `${e.clientX}px`;
    cursorDot.style.top = `${e.clientY}px`;
  });
}

document.querySelectorAll(".neo-box").forEach(el => {
  el.addEventListener("pointerdown", () => {
    if (window.matchMedia("(pointer:fine)").matches) {
      el.style.transform = "translate(3px,3px)";
    }
  });
  el.addEventListener("pointerup", () => el.style.transform = "");
  el.addEventListener("pointerleave", () => el.style.transform = "");
});


// Open/close the pirate atlas and reveal the home-region treasure map.
const pirateBook = document.getElementById("pirateBook");
const mapCaption = document.getElementById("mapCaption");
let isAutoOpening = false;

pirateBook?.addEventListener("click", () => {
  isAutoOpening = false;
  const opened = pirateBook.classList.toggle("is-open");
  pirateBook.setAttribute("aria-expanded", String(opened));
  if (mapCaption) mapCaption.textContent = opened
    ? "Peta terbuka! Indonesia, Kalimantan Tengah, Barito Selatan, Dusun Selatan, Buntok, Hilir Sper."
    : "Sebuah buku tua menyimpan lokasi markas kapten...";
});

// Scroll-triggered auto open/close for pirate book
const pirateBookWrap = document.querySelector(".pirate-book-wrap");
if (pirateBookWrap && pirateBook) {
  const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
        // User is scrolling INTO the book section
        if (!pirateBook.classList.contains("is-open")) {
          isAutoOpening = true;
          pirateBook.classList.add("is-open");
          pirateBook.setAttribute("aria-expanded", "true");
          if (mapCaption) mapCaption.textContent = "Peta terbuka! Indonesia, Kalimantan Tengah, Barito Selatan, Dusun Selatan, Buntok, Hilir Sper.";
        }
      } else if (!entry.isIntersecting || entry.intersectionRatio < 0.3) {
        // User has scrolled PAST the book section
        if (pirateBook.classList.contains("is-open") && isAutoOpening) {
          pirateBook.classList.remove("is-open");
          pirateBook.setAttribute("aria-expanded", "false");
          if (mapCaption) mapCaption.textContent = "Sebuah buku tua menyimpan lokasi markas kapten...";
        }
      }
    });
  }, { threshold: [0.3, 0.5] });

  scrollObserver.observe(pirateBookWrap);
}
