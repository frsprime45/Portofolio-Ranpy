# Neo Yellow Portfolio

Portfolio responsive bergaya Neo Brutalism 3D, terinspirasi dari referensi video yang diberikan:
- background putih
- yellow sebagai warna utama
- black sebagai border + hard shadow
- kartu tebal / offset shadow
- animasi reveal saat scroll
- mobile navigation
- hover / press interaction
- layout responsive HP, tablet, laptop, PC

## Struktur
index.html
style.css
script.js
assets/
  profile.jpg
  project-1.jpg
  project-2.jpg
  project-3.jpg
  README.txt

## Cara memakai
1. Buka `index.html`.
2. Ganti `YOUR NAME`, deskripsi, skill, project, link sosial, dan email.
3. Masukkan foto profil ke `assets/profile.jpg`.
4. Masukkan screenshot project ke:
   - `assets/project-1.jpg`
   - `assets/project-2.jpg`
   - `assets/project-3.jpg`
5. Tidak perlu backend untuk versi ini.

Catatan: file JPG placeholder sengaja tidak disertakan sebagai gambar palsu. Jika gambar belum dimasukkan, website otomatis menampilkan placeholder.


## Update: Pirate Atlas & Skill Images
- Kartu lokasi sekarang berupa buku peta harta karun; ketuk bukunya untuk membuka/menutup animasi.
- Edit teks `KALIMANTAN, INDONESIA` dan keterangan lokasi di bagian `.map-location` pada `index.html` sesuai daerahmu.
- Ganti JPG placeholder skill di folder `assets/` dengan logo/gambar milikmu, pertahankan nama file: `skill-html.jpg`, `skill-css.jpg`, `skill-javascript.jpg`, `skill-python.jpg`, `skill-cpp.jpg`, `skill-php.jpg`, `skill-sql.jpg`, dan `skill-nodejs.jpg`.
